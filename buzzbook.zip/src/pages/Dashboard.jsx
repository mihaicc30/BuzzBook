import { Fragment, useState } from "react";
import DatePicker from "react-date-picker";
import "react-date-picker/dist/DatePicker.css";
import "react-calendar/dist/Calendar.css";

// https://www.npmjs.com/package/react-calendar
// https://github.com/wojtekmaj/react-date-picker

export default function Dashboard() {
  const [value, onChange] = useState(new Date());

  const generateHoursArray = () => {
    const hours = [];
    for (let hour = 7; hour <= 23; hour++) {
      hours.push(hour);
    }
    return hours;
  };

  const generateTemplateData = () => {
    const hours = [];
    for (let hour = 7; hour <= 23; hour++) {
      hours.push(hour);
    }
    return hours;
  };

  // each section has a set of tables
  const sections = ["Section1", "Section2", "Section3", "Section4", "Section5"];
  const tables = ["T1", "T2", "T3", "T4", "T5"];

  return (
    <>
      <div className={`flex justify-center flex-col mx-auto`}>
        <DatePicker
          onChange={onChange}
          value={value}
        />
        <div>
          <span>Total Bookings XX</span> - <span>Total Covers: XX</span>
        </div>
      </div>

      <div className="overflow-auto ">
        <div className="grid grid-cols-1 w-[100svw] relative">
          <GetWorkingHours />
          {sections.map((section, index) => {
            return (
              <>
                <div className="grid grid-flow-col auto-cols-[50px] h-12 items-center border-b-2 border-b-black/[2%]">
                  <span className="sectionName sticky left-0 z-1 bg-white whitespace-nowrap font-[600]">{section}</span>
                  {generateHoursArray().map((_) => (
                    <Fragment key={crypto.randomUUID()}>
                      <span className="tableNullPlaceholder"></span>
                      <span className="tableNullPlaceholder"></span>
                      <span className="tableNullPlaceholder"></span>
                      <span className="tableNullPlaceholder"></span>
                    </Fragment>
                  ))}
                </div>
                <GetTableData tables={tables} />
              </>
            );
          })}
        </div>
      </div>
    </>
  );
}

const GetTableData = ({ tables }) => {
  const generateHoursArray = () => {
    const hours = [];
    for (let hour = 7; hour <= 23; hour++) {
      hours.push(hour);
    }
    return hours;
  };

  return (
    <>
      {tables.map((tn) => {
        return (
          <Fragment key={crypto.randomUUID()}>
            <div className="grid grid-flow-col auto-cols-[50px] h-12 items-center border-b-2 border-b-black/[2%]">
              <span className="tableName sticky left-0 z-1 whitespace-nowrap bg-white">{tn}</span>
              {generateHoursArray().map((_) => (
                <Fragment key={crypto.randomUUID()}>
                  <span className="tableData">(data)</span>
                  <span className="tableData">(data)</span>
                  <span className="tableData">(data)</span>
                  <span className="tableData">(data)</span>
                </Fragment>
              ))}
            </div>
          </Fragment>
        );
      })}
    </>
  );
};

const GetWorkingHours = () => {
  const generateHoursArray = () => {
    const hours = [];
    for (let hour = 7; hour <= 23; hour++) {
      hours.push(hour);
    }
    return hours;
  };

  return (
    <div className="grid grid-flow-col auto-cols-[50px] h-12 items-center border-b-2 border-b-black/[2%]">
      <span></span>
      {generateHoursArray().map((hour) => (
        <Fragment key={hour}>
          <span className="font-bold sticky top-0 w-[20px] whitespace-nowrap">
            {hour}
            <span className="text-[10px] font-normal">:00</span>
          </span>
          <span className="font-thin sticky top-0 w-[20px]">15</span>
          <span className="font-thin sticky top-0 w-[20px]">30</span>
          <span className="font-thin sticky top-0 w-[20px]">45</span>
        </Fragment>
      ))}
    </div>
  );
};
